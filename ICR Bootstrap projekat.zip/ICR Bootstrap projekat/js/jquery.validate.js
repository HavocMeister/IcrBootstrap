// $(document).ready(function () {

//     $("#form").validate({ // initialize the plugin
//         rules: {
//             cname: {
//                 required: true,
//                 email: true
//             },
//             surname: {
//                 required: true,
//                 minlength: 5
//             }
//         }
//     });

// });